import  { useContext, useState,useRef } from 'react';
import { toast } from 'react-toastify';
import axios from 'axios';
import { UserContext } from '../UserContext';

export default function AddEvent() {
  const {user} = useContext(UserContext);
  const fileInputRef = useRef(null);
  const [formData, setFormData] = useState({

    owner: user? user.name : "",
    title: "",
    // optional:"",
    description: "",
    organizedBy: "",
    eventDate: "",
    eventTime: "",
    location: "",
    ticketPrice: 0,
    image:null,
    likes: 0
  });

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    setFormData((prevState) => ({ ...prevState, image: file }));
  };

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    if (files) {
      setFormData((prevState) => ({ ...prevState, [name]: files[0] }));
    } else {
      setFormData((prevState) => ({ ...prevState, [name]: value }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const currentDate = new Date();
    const eventDate = new Date(formData.eventDate);

    if (eventDate < currentDate) {
      console.error("Event date cannot be in the past");
      // Optionally, display an error message to the user
      toast("The event date is invalid.");
      return; // Prevent form submission if the date is invalid
  }

     // Create a FormData object
    const multipartFormData = new FormData();
    Object.entries(formData).forEach(([key, value]) => {
      if (key === "image" && value) {
        // Append file only if it exists
        multipartFormData.append("image", value); // 'image' should match the backend field name
      } else {
        multipartFormData.append(key, value);
      }
    });
    
  
    axios
      .post("/createEvent", multipartFormData)
      .then((response) => {
        console.log("Event posted successfully:", response.data);

        toast("Event submitted successfully!");
      setFormData({
        owner: user ? user.name : "",
        title: "",
        // optional: "",
        description: "",
        organizedBy: "",
        eventDate: "",
        eventTime: "",
        location: "",
        ticketPrice: 0,
        image: null, // Reset to `null`
        likes: 0,
      });

      // Clear the file input field using the ref
      if (fileInputRef.current) {
        fileInputRef.current.value = ""; // Reset the file input
      }
    })
      .catch((error) => {
        console.error("Error posting event:", error);
      });
      
  };

  return (
    <div className="flex flex-row gap-[150px] items-center">
    <div className='flex flex-col ml-20 mt-10'>
      <div><h1 className='font-bold text-[36px] mb-5'>Post an Event</h1></div>
      <form onSubmit={handleSubmit} className='flex flex-co'>
      <div className='flex flex-col gap-5'>
        <label className='flex flex-col'>
          Title:
          <input
            type="text"
            name="title"
            className=' rounded mt-2 pl-5 px-4 ring-sky-700 ring-2 h-8 border-none'
            value={formData.title}
            onChange={handleChange}
            required
          />
        </label>
        {/* <label className='flex flex-col'>
          Optional:
          <input
            type="text"
            name="optional"
            className=' rounded mt-2 pl-5 px-4 ring-sky-700 ring-2 h-8 border-none'
            value={formData.optional}
            onChange={handleChange}
            required
          />
        </label > */}
        <label className='flex flex-col'>
          Description:
          <textarea
            name="description"
            className=' rounded mt-2 pl-5 px-4 py-2 ring-sky-700 ring-2 h-9 text-base max-w-xs'
            value={formData.description}
            onChange={handleChange}
            required
          />
        </label>
        <label className='flex flex-col'>
          Organized By:
          <input
            type="text"
            className=' rounded mt-2 pl-5 px-4 ring-sky-700 ring-2 h-8 border-none'
            name="organizedBy"
            value={formData.organizedBy}
            onChange={handleChange}
            required
          />
        </label>
        <label className='flex flex-col'>
          Event Date:
          <input
            type="date"
            className=' rounded mt-2 pl-5 px-4 ring-sky-700 ring-2 h-8 border-none'
            name="eventDate"
            value={formData.eventDate}
            onChange={handleChange}
            required
          />
        </label>
        <label className='flex flex-col'>
          Event Time:
          <input
            type="time"
            name="eventTime"
            className=' rounded mt-2 pl-5 px-4 ring-sky-700 ring-2 h-8 border-none'
            value={formData.eventTime}
            onChange={handleChange}
            required
          />
        </label>
        <label className='flex flex-col'>
          Location:
          <input
            type="text"
            name="location"
            className=' rounded mt-2 pl-5 px-4 ring-sky-700 ring-2 h-8 border-none'
            value={formData.location}
            onChange={handleChange}
            required
          />
        </label>
        <label className='flex flex-col'>
          Ticket Price:
          <input
            type="number"
            name="ticketPrice"
            className=' rounded mt-2 pl-5 px-4 ring-sky-700 ring-2 h-8 border-none'
            value={formData.ticketPrice}
            onChange={handleChange}
            required
          />
        </label>
        <label className='flex flex-col'>
          Image:
          <input
            type="file"
            name="image"
            ref={fileInputRef}
            className=' rounded mt-2 pl-5 px-4 py-10 ring-sky-700 ring-2 h-8 border-none'
            onChange={handleImageUpload}
            required
          />
        </label >
        <button className='primary' type="submit">Submit</button>
        </div>
        
      </form>
    </div>
    <div className="mx-auto"> <img src="../src/assets/ticketpageimage.png" alt="ticketpageimage" /></div>
    </div>
  );
}
